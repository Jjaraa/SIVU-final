
package lanzador;

import gestor.DirectoryFile;
import gestor.InventarioFile;
import gestor.UserFile;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import logico.Producto;
import interfazGrafica.*;
/**
 *
 * @author Master
 */
public class Main {

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        //Date fecha = new Date();
        //JOptionPane.showMessageDialog(null, fecha);
        MenuVenta m= new MenuVenta();
        MenuAgregarProducto ma= new MenuAgregarProducto();
        
        
        ArrayList<Producto> inventario = new ArrayList<Producto>();
        Producto producto1 = new Producto("LapizAzul",200,40,1000000,20);
        Producto producto2 = new Producto("Goma",230,70,1000001,100);
        Producto producto3 = new Producto("LapizNegro",100,56,1000002,200);
        Producto producto4 = new Producto("Tijeras",500,23,1000003,300);
        Producto producto5 = new Producto("Blabla",20,15,1000004,500);
        Producto producto6 = new Producto("Blibli",1800,467,1000005,400);
        inventario.add(producto1);
        inventario.add(producto2);
        inventario.add(producto3);
        inventario.add(producto4);
        inventario.add(producto5);
        inventario.add(producto6);
        
        System.out.println(inventario.get(inventario.size()-1).getNombre());
        
       
        
    }}

