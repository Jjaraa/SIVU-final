/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package interfazGrafica;
import ventana.*;
import logico.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.text.InternationalFormatter;
/**
 * 
 * @author Oscar
 */
public class MenuAgregarProducto extends Ventana {
JTextField nombreProducto;
JFormattedTextField precioProducto;
JComboBox categorias,subcategoria;
JButton botonAceptar,botonCancelar,botonAñadirCategoria,botonAñadirSubcategoria;
JLabel textoEncabezado, textoNombreProducto, textoPrecio;
public MenuAgregarProducto(){
super("SIVU",500,400);
generarElementosVentana();
}

private void generarElementosVentana(){
generarCategorias();
generarBotones();
generarCamposTexto();
generarLabels();
repaint();
}
private void generarCategorias(){
this.categorias= new JComboBox();
SIVU sivu= new SIVU();
ArrayList<Categoria> categoria= sivu.getCategorias();
this.categorias.addItem("Elije una categoría");
for(int i=0; i<categoria.size();i++){
this.categorias.addItem(categoria.get(i).getNombre());
} 
this.categorias.setBounds(20, 60, 120, 20);
this.add(this.categorias);
}
private void generarSubCategorias(String categoriaElegida){
SIVU sivu= new SIVU();
ArrayList<Categoria> categoria= sivu.getCategorias();
this.subcategoria= new JComboBox();
this.subcategoria.addItem("Elije una subcategoría");
for(int i=0; i<categoria.size();i++){
if(categoria.get(i).getNombre().equals(categoriaElegida)){
 ArrayList<SubCategoria> subcategoria= categoria.get(i).getSubCategorias();
for(int j=0; j<subcategoria.size();j++){
this.subcategoria.addItem(subcategoria.get(i).getNombre());
this.add(this.categorias);
}
}
}
this.subcategoria.setBounds(150, 60, 120, 20);
this.add(this.subcategoria);
}
private void generarBotones(){
this.botonAceptar=super.generarBoton("Aceptar", 300, 300, 150, 20);
this.add(this.botonAceptar);
this.botonAceptar.addActionListener(this);
this.botonAñadirCategoria=super.generarBoton("Agregar categoria", 30, 100, 200, 20);
this.add(this.botonAñadirCategoria);
this.botonAñadirCategoria.addActionListener(this);
this.botonAñadirSubcategoria=super.generarBoton("Agregar subcategoria", 255, 100, 200, 20);
this.add(this.botonAñadirSubcategoria);
this.botonAñadirSubcategoria.addActionListener(this);
this.botonCancelar=super.generarBoton("Cancelar", 50, 300, 150, 20);
this.add(this.botonCancelar);
this.botonCancelar.addActionListener(this);
}

private void generarCamposTexto(){
this.nombreProducto= super.generarJTextField(200, 150, 150, 20);
this.add(this.nombreProducto);
 InternationalFormatter formato = super.generarFormato(1);
 this.precioProducto=super.generarJFormattedTextField(formato, 200, 200, 150, 20);
this.add(this.precioProducto);
}
private void generarLabels(){
super.generarJLabelEncabezado(this.textoEncabezado, "Agregar producto", 20, 10, 250, 40);
super.generarJLabel(this.textoNombreProducto, "Nombre producto:", 20, 150, 150, 20);
super.generarJLabel(this.textoPrecio, "Precio unitario:", 20, 200, 150, 20);
}
/**
 * Este método gestiona los eventos de la ventana
 */
    @Override
    public void actionPerformed(ActionEvent e) {
 
    if(e.getSource()==this.botonAñadirCategoria){
           String nombreCategoria;
           
    nombreCategoria=JOptionPane.showInputDialog("Ingrese el nombre de su nueva Categoria");
if(nombreCategoria==null || nombreCategoria.equals("")){
}
else{
        SIVU sivu= new SIVU();
      sivu.agregarCategoria(nombreCategoria);
    }}
    if(e.getSource()==this.botonAñadirSubcategoria){
    int indice=this.categorias.getSelectedIndex();
    if(indice==0){
    Object a=this.categorias.getItemAt(indice);
 String categoria = a.toString();
 generarSubCategorias(categoria);
            

    
    
    }
        
    }
    
    }
}