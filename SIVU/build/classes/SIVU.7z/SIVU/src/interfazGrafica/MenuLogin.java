/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfazGrafica;

import ventana.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author Oscar
 */
public class MenuLogin extends Ventana {

    private JPasswordField contraseña;
    private JTextField nombreUsuario;
    private JLabel textoContraseña, textoEncabezado, textoUsuario;
    private JButton botonAceptar, botonCancelar;

    public MenuLogin() {
        super("SIVU", 500, 400);
        generarElementosVentana();
    }

    private void generarElementosVentana() {
        generarCamposTexto();
        generarBotones();
        generarTexto();
        repaint();

    }

    private void generarCamposTexto() {
        this.nombreUsuario = super.generarJTextField(200, 120, 150, 20);
        this.add(this.nombreUsuario);
        this.contraseña = super.generarJPasswordField(200, 200, 150, 20);
        this.add(this.contraseña);
    }

    private void generarBotones() {
        this.botonAceptar = super.generarBoton("Aceptar", 300, 300, 150, 20);
        this.add(this.botonAceptar);
        this.botonAceptar.addActionListener(this);
        this.botonCancelar = super.generarBoton("Cancelar", 50, 300, 150, 20);
        this.add(this.botonCancelar);
        this.botonCancelar.addActionListener(this);
    }

    private void generarTexto() {
        super.generarJLabel(this.textoContraseña, "Contraseña:", 20, 200, 150, 20);
        super.generarJLabelEncabezado(this.textoEncabezado, "Inicio de sesión", 150, 20, 250, 20);
        super.generarJLabel(this.textoUsuario, "Usuario:", 20, 120, 150, 20);
    }

    private void verificarDatosVendedor() {
        //llamar metodo
        boolean condicion = true;
        if (condicion == true) {
            MenuVendedor menu = new MenuVendedor();
            this.dispose();

        } else {
            JOptionPane.showMessageDialog(this, "Datos erróneos, intentelo nuevamente");
        }

    }

    private void verificarDatosAdministrador() {
        boolean condicion = true;
        //llamar metodo
        if (condicion == true) {
            MenuAdministrador menu = new MenuAdministrador();
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Datos erróneos, intentelo nuevamente");
        }

    }
/**
 * Este método gestiona los eventos de la ventana
 */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.botonAceptar) {
            if (this.nombreUsuario.getText().length() == 0 || this.contraseña.getText().length() == 0) {
                JOptionPane.showMessageDialog(this, "Ingrese todos los datos");
            } else {
                if (this.nombreUsuario.getText().equals("admin")) {
                    verificarDatosAdministrador();
                }
            }

        }
        if (e.getSource() == this.botonCancelar) {
            Bienvenida bienvenida = new Bienvenida();
        }
    }
}
