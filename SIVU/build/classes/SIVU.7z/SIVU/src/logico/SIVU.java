package logico;

import gestor.DirectoryFile;
import gestor.InventarioFile;
import gestor.UserFile;
import gestor.VentaFile;
import java.util.ArrayList;
import java.util.Iterator;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Master
 */
public class SIVU {

    private ArrayList<Producto> productos;
    private ArrayList<Venta> ventas;
    private ArrayList<Vendedor> vendedores;
    private ArrayList<Categoria> categorias;
    private Admin administrador;

    /**
     * El constructor solamente instancia los atributos de clase.
     */
    public SIVU() {
        this.productos = new ArrayList<Producto>();
        this.ventas = new ArrayList<Venta>();
        this.vendedores = new ArrayList<Vendedor>();
        this.categorias = new ArrayList<Categoria>();

    }

    /**
     * Retorna las ventas.
     *
     * @return ArrayList<Venta>
     */
    public ArrayList<Venta> getVentas() {
        generarVentas();
        return this.ventas;
    }

    /**
     * Retorna el inventario.
     *
     * @return ArrayList<Producto>
     */
    public ArrayList<Producto> getProductos() {
        return this.productos;
    }

    /**
     * Retorna la lista de vendedores.
     *
     * @return ArrayList<Vendedor>
     */
    public ArrayList<Vendedor> getVendedores() {
        return this.vendedores;
    }

    /**
     * Retorna la lista de categorias.
     *
     * @return ArrayList<Categoria>
     */
    public ArrayList<Categoria> getCategorias() {
        return this.categorias;
    }

    /**
     * Retorna el administrador de SIVU
     *
     * @return Admin
     */
    public Admin getAdministrador() {
        return this.administrador;
    }

    /**
     * Metodo para configurar los archivos en el primer inicio del programa.
     */
    public void generarPrimerInicio() {
        DirectoryFile directorio = new DirectoryFile();
        UserFile userFile = new UserFile();
        directorio.crearDirectoriosSIVU();
        userFile.crearAdmin();
    }

    /**
     * Método para cargar todos los archivos del programa.
     */
    public void cargarArchivos() {
        InventarioFile gestorInventario = new InventarioFile();
        UserFile gestorUser = new UserFile();
        VentaFile gestorVenta = new VentaFile();
        this.productos = gestorInventario.leerInventario();
        this.vendedores = gestorUser.leerVendedor();
        this.ventas = gestorVenta.leerVentasTotales();
        this.administrador = gestorUser.leerAdmin();
        cargarVentaVendedores();

    }

    /**
     * Método que guarda todos los datos en sus respectivos archivos. Retorna
     * true cuando termina.
     *
     * @return boolean
     */
    public boolean terminarDia() {
        InventarioFile gestorInventario = new InventarioFile();
        UserFile gestorUser = new UserFile();
        VentaFile gestorVenta = new VentaFile();
        generarVentas();
        gestorInventario.guardarCategorias(this.categorias);
        gestorInventario.guardarInventario(this.productos);
        gestorUser.guardarAdmin(this.administrador);
        gestorUser.guardarVendedores(this.vendedores);
        gestorVenta.grabarVentasTotales(this.ventas);
        guardarVentaVenderores();
        gestorInventario.guardarSubCategorias(obtenerSubCategorias());
        return true;

    }

    /**
     * Retorna el vendedor que corresponda al nombre de usuario con que se
     * buscó. La busqueda se hace dentro de la lista de vendedores.
     *
     * @param nombreUsuario
     * @return Vendedor
     */
    public Vendedor buscarVendedor(String nombreUsuario) {
        Vendedor vendedor1 = new Vendedor(null, null, null);
        for (Vendedor item : this.vendedores) {
            if (nombreUsuario.equals(item.getNombreUsuario())) {
                vendedor1 = item;
            }
        }
        return vendedor1;

    }

    /**
     * Método que retorna todos los valores de cada producto de una categoria en
     * especifico. Incluye todos los productos de todas las subcategorias.
     *
     * @param nombreCategoria
     * @return String[][]
     */
    public String[][] retornarCategoria(String nombreCategoria) {
        ArrayList<Producto> productosTotales = sumarSubCategorias(nombreCategoria);
        String[][] valoresProductos = new String[productosTotales.size()][6];
        int contador = 0;
        for (Producto item : productosTotales) {
            valoresProductos[contador][0] = Integer.toString(item.getCodigo());
            valoresProductos[contador][1] = item.getNombre();
            valoresProductos[contador][2] = Integer.toString(item.getStock());
            valoresProductos[contador][3] = Integer.toString(item.getStockCritico());
            valoresProductos[contador][4] = Integer.toString(item.getPrecio());
            contador++;
        }
        return valoresProductos;
    }

    /**
     * Método para agregar una nueva categoria a la lista de categorias.
     *
     * @param nombre
     */
    public void agregarCategoria(String nombre) {
        int ultimoCodigo = this.categorias.get(this.categorias.size() - 1).getCodigo();
        Categoria categoria = new Categoria(ultimoCodigo + 1, nombre);
        this.categorias.add(categoria);
    }

    /**
     * Método para agregar una subcategoria a una categoria.
     *
     * @param categoria
     * @param nombre
     */
    public void agregarSubCategoria(Categoria categoria, String nombre) {
        int ultimoCodigo = categoria.getSubCategorias().get(categoria.getSubCategorias().size()).getCodigo();
        SubCategoria sub = new SubCategoria(ultimoCodigo + 1, nombre, categoria);
        categoria.getSubCategorias().add(sub);
    }

    /**
     * Retorna los nombres de todos los vendedores.
     *
     * @return String[]
     */
    public String[] retornarVendedores() {
        int numeroVendedores = this.vendedores.size();
        String[] nombreVendedores = new String[numeroVendedores];
        int contador = 0;
        for (Vendedor item : this.vendedores) {
            nombreVendedores[contador] = item.getNombre();
            contador++;
        }
        return nombreVendedores;
    }

    private ArrayList<Producto> sumarSubCategorias(String nombreCategoria) {
        Categoria categoria = buscarCategoria(nombreCategoria);
        ArrayList<Producto> productosTotales = new ArrayList<>();
        for (SubCategoria item : categoria.getSubCategorias()) {
            for (Producto objeto : item.getProductosDeSubCategoria()) {
                productosTotales.add(objeto);
            }
        }
        return productosTotales;
    }

    private Categoria buscarCategoria(String nombreCategoria) {
        Categoria categoriaBuscada = null;
        for (Categoria item : this.categorias) {
            if (nombreCategoria.equals(item.getNombre())) {
                categoriaBuscada = item;
            }
        }
        return categoriaBuscada;
    }

    private void generarVentas() {
        ArrayList<Venta> ventasTotales = new ArrayList<>();
        for (Vendedor item : this.vendedores) {
            for (Venta objet : item.getVentasUsuario()) {
                ventasTotales.add(objet);
            }
        }
        this.ventas = ventasTotales;
    }

    private void guardarVentaVenderores() {
        VentaFile gestorUser = new VentaFile();
        for (Vendedor item : this.vendedores) {
            gestorUser.grabarVentaVendedor(item, this.ventas);
        }
    }

    private void cargarVentaVendedores() {
        VentaFile gestorVenta = new VentaFile();
        for (Vendedor item : this.vendedores) {
            item.setVentas(gestorVenta.leerVentaVendedor(item));
        }

    }

    private ArrayList<SubCategoria> obtenerSubCategorias() {
        ArrayList<SubCategoria> SubCategoriasTotales = new ArrayList<>();
        for (Categoria item : this.categorias) {
            for (SubCategoria objet : item.getSubCategorias()) {
                SubCategoriasTotales.add(objet);
            }
        }
        return SubCategoriasTotales;
    }

    /**
     * Método que se encarga de la creación de Categorias recibiendo un arreglo
     * de String directamente desde la lectura de archivos. Devolviendo el
     * arreglo de tipo Categoria.
     *
     * @param categorias
     * @return ArrayList<Categoria>
     */
    public ArrayList<Categoria> crearCategorias(ArrayList<String> categorias) {
        ArrayList<Categoria> categoriasFinales = new ArrayList<>();
        for (int i = 0; i < categorias.size(); i = +2) {
            int codigoCategoria = Integer.parseInt(categorias.get(i));
            String nombreCategoria = categorias.get(i + 1);
            categoriasFinales.add(new Categoria(codigoCategoria, nombreCategoria));
        }
        return categoriasFinales;
    }

    /**
     * Método encargado de la creación de las Sub Categorias. Recibiendo un
     * arreglo de String con los nombres y codigos de estas desde la lectura de
     * archivos. Recibe el Arreglo de tipo Categoria para asignarle a cada una
     * su subcategoria.
     *
     * @param subCategorias
     * @param categoriasFinales
     */
    //codigoCategoria;codigoSub;NombreSub
    public void crearSubCategorias(ArrayList<String> subCategorias, ArrayList<Categoria> categoriasFinales) {
        for (int i = 0; i < subCategorias.size(); i = +3) {
            int codigoCategoria = Integer.parseInt(subCategorias.get(i));
            String nombreSubCategoria = subCategorias.get(i + 1);
            int codigoSubCategoria = Integer.parseInt(subCategorias.get(i + 2));

            Iterator<Categoria> it = categoriasFinales.iterator();
            while (it.hasNext()) {
                Categoria cat = it.next();
                if (cat.getCodigo() == codigoCategoria) {
                    cat.addSubCategoria(new SubCategoria(codigoSubCategoria, nombreSubCategoria, cat));
                }
            }
        }
    }

    /**
     * Método encargado de separar los productos según sus codigos
     * correspondiente a Categoria.
     *
     * @param Productos
     * @param categoriasFinales
     */
    public void separarProductos(ArrayList<Producto> Productos, ArrayList<Categoria> categoriasFinales) {
        for (int i = 0; i < Productos.size(); i++) {
            String categoria = "";
            String subCategoria = "";
            String codigo = Integer.toString(Productos.get(i).getCodigo());
            char[] chars = codigo.toCharArray();
            categoria += chars[0];
            categoria += chars[1];
            subCategoria += chars[2];
            subCategoria += chars[3];
            int categoriaFinal = Integer.parseInt(categoria);
            int subCategoriaFinal = Integer.parseInt(subCategoria);
            Iterator<Categoria> it = categoriasFinales.iterator();
            while (it.hasNext()) {
                Categoria cat = it.next();
                if (cat.getCodigo() == categoriaFinal) {
                    cat.addProducto(Productos.get(i), subCategoriaFinal);
                }
            }
        }
    }

    /**
     * Método para añadir un nuevo producto a la Categoría y Sub Categoría
     * deseada. Retornara true si se añadio correctamente y retornara false si
     * esto no se realizó.
     *
     * @param categoriasFinales
     * @param nombreCategoria
     * @param nombreSubCategoria
     * @param nombreProducto
     * @param precio
     * @return boolean
     */
    public boolean añadirNuevoProducto(ArrayList<Categoria> categoriasFinales, String nombreCategoria, String nombreSubCategoria, String nombreProducto, int precio) {
        boolean estado = false;
        Iterator<Categoria> it = categoriasFinales.iterator();
        while (it.hasNext()) {
            Categoria cat = it.next();
            if (cat.getNombre().equals(nombreCategoria)) {
                estado = cat.addNewProducto(nombreSubCategoria, nombreProducto, precio);
            }
        }
        return estado;
    }

    /**
     * Método que retorna un arreglo de tipo Producto con todos los productos en
     * todas las Categorias y Subcategorias.
     *
     * @param categoriasFinales
     * @return
     */
    public ArrayList<Producto> getInventarioTotal(ArrayList<Categoria> categoriasFinales) {
        ArrayList<Producto> productoTotal = new ArrayList<>();
        for (int i = 0; i < categoriasFinales.size(); i++) {
            for (int j = 0; i < categoriasFinales.get(i).getSubCategorias().size(); i++) {
                for (int k = 0; k < categoriasFinales.get(i).getSubCategorias().get(j).getProductosDeSubCategoria().size(); k++) {
                    productoTotal.add(categoriasFinales.get(i).getSubCategorias().get(j).getProductosDeSubCategoria().get(k));
                }
            }
        }
        return productoTotal;
    }

    /**
     * Método el cual se encarga de entregar un arreglo con los nombres de todas
     * las categorias.
     *
     * @param categoriasFinales
     * @return ArrayList<String>
     */
    public ArrayList<String> getNombresCategorias(ArrayList<Categoria> categoriasFinales) {
        ArrayList<String> nombreCategoria = new ArrayList<>();
        for (int i = 0; i < categoriasFinales.size(); i++) {
            nombreCategoria.add(categoriasFinales.get(i).getNombre());
        }
        return nombreCategoria;
    }

    /**
     * Método el cual se encarga de entregar un arreglo con los nombres de todas
     * las Sub Categorias.
     *
     * @param categoriasFinales
     * @param nombreCategoria
     * @return
     */
    public ArrayList<String> getNombreSubcategorias(ArrayList<Categoria> categoriasFinales, String nombreCategoria) {
        ArrayList<String> nombreSubCategoria = new ArrayList<>();
        Iterator<Categoria> it = categoriasFinales.iterator();
        while (it.hasNext()) {
            Categoria cat = it.next();
            if (cat.getNombre().equals(nombreCategoria)) {
                for (int i = 0; i < cat.getSubCategorias().size(); i++) {
                    nombreSubCategoria.add(cat.getSubCategorias().get(i).getNombre());
                }
            }
        }
        return nombreSubCategoria;
    }
}
